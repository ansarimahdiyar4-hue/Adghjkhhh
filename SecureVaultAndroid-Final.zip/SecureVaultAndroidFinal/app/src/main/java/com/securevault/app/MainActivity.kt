package com.securevault.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent { SecureVaultRoot() }
    }
}

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF34C9FF),
    tertiary = Color(0xFF7CE7C4),
    background = Color(0xFF080D18),
    surface = Color(0xFF101827),
    surfaceVariant = Color(0xFF192234),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFFB8C1D1),
    error = Color(0xFFFF6B7A)
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF5F4BEA),
    onPrimary = Color.White,
    secondary = Color(0xFF007FA8),
    tertiary = Color(0xFF006C52),
    background = Color(0xFFF6F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFE9ECF4),
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827),
    onSurfaceVariant = Color(0xFF526075),
    error = Color(0xFFB3261E)
)

@Composable
fun SecureVaultRoot() {
    val context = LocalContext.current
    val store = remember { VaultStore(context.applicationContext) }
    val prefs = remember { AppPrefs(context.applicationContext) }

    var unlocked by rememberSaveable { mutableStateOf(false) }
    var master by remember { mutableStateOf("") }
    var vault by remember { mutableStateOf(VaultData()) }
    var authError by remember { mutableStateOf<String?>(null) }
    var themeMode by remember { mutableStateOf(prefs.themeMode) }
    var autoLockSeconds by remember { mutableIntStateOf(prefs.autoLockSeconds) }
    var lastActivity by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) {
        "light" -> false
        "system" -> systemDark
        else -> true
    }

    fun lock() {
        master = ""
        vault = VaultData()
        unlocked = false
        authError = null
    }

    LaunchedEffect(unlocked, autoLockSeconds) {
        while (unlocked) {
            delay(5_000)
            if (System.currentTimeMillis() - lastActivity >= autoLockSeconds * 1000L) lock()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, unlocked) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && unlocked) lock()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme) {
        Surface(color = MaterialTheme.colorScheme.background) {
            if (!unlocked) {
                AuthScreen(
                    hasVault = store.exists(),
                    error = authError,
                    onSubmit = { password, confirmation ->
                        authError = null
                        try {
                            if (password.length < 12) {
                                authError = "رمز اصلی باید حداقل ۱۲ کاراکتر باشد."
                            } else if (!store.exists()) {
                                if (password != confirmation) {
                                    authError = "تکرار رمز با رمز اصلی یکسان نیست."
                                } else {
                                    val fresh = VaultData()
                                    store.save(fresh, password.toCharArray())
                                    vault = fresh
                                    master = password
                                    unlocked = true
                                    lastActivity = System.currentTimeMillis()
                                }
                            } else {
                                vault = store.load(password.toCharArray())
                                master = password
                                unlocked = true
                                lastActivity = System.currentTimeMillis()
                            }
                        } catch (_: Exception) {
                            authError = "رمز اصلی اشتباه است یا فایل Vault معتبر نیست."
                        }
                    }
                )
            } else {
                VaultAppScreen(
                    vault = vault,
                    master = master,
                    store = store,
                    themeMode = themeMode,
                    autoLockSeconds = autoLockSeconds,
                    onActivity = { lastActivity = System.currentTimeMillis() },
                    onVaultChanged = { changed ->
                        vault = changed
                        store.save(changed, master.toCharArray())
                        lastActivity = System.currentTimeMillis()
                    },
                    onMasterChanged = { newMaster ->
                        master = newMaster
                        lastActivity = System.currentTimeMillis()
                    },
                    onThemeModeChanged = { mode ->
                        themeMode = mode
                        prefs.themeMode = mode
                    },
                    onAutoLockChanged = { seconds ->
                        autoLockSeconds = seconds
                        prefs.autoLockSeconds = seconds
                        lastActivity = System.currentTimeMillis()
                    },
                    onRestore = { restored ->
                        vault = restored
                        lastActivity = System.currentTimeMillis()
                    },
                    onLock = { lock() }
                )
            }
        }
    }
}
