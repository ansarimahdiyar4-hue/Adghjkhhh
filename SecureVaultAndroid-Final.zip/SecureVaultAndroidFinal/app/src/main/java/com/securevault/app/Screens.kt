package com.securevault.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val GradientA = Color(0xFF7357FF)
private val GradientB = Color(0xFF17C7FF)

private enum class AppTab(val label: String) {
    HOME("Vault"),
    GENERATOR("تولید رمز"),
    SECURITY("امنیت"),
    SETTINGS("تنظیمات")
}

@Composable
fun AuthScreen(
    hasVault: Boolean,
    error: String?,
    onSubmit: (String, String) -> Unit
) {
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    val transition = rememberInfiniteTransition(label = "logoPulse")
    val scale by transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "logoScale"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background
                        )
                    )
                )
                .padding(horizontal = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .scale(scale)
                        .size(92.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .background(Brush.linearGradient(listOf(GradientA, GradientB))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(48.dp))
                }

                Spacer(Modifier.height(22.dp))
                Text("SecureVault", fontSize = 32.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(6.dp))
                Text(
                    if (hasVault) "گاوصندوق رمزگذاری‌شده‌ات را باز کن" else "یک گاوصندوق امن برای رمزها بساز",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(30.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("رمز اصلی") },
                    leadingIcon = { Icon(Icons.Default.Key, null) },
                    trailingIcon = {
                        IconButton(onClick = { showPassword = !showPassword }) {
                            Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                        }
                    },
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    shape = RoundedCornerShape(18.dp)
                )

                AnimatedVisibility(!hasVault) {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = confirm,
                            onValueChange = { confirm = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("تکرار رمز اصلی") },
                            leadingIcon = { Icon(Icons.Default.Lock, null) },
                            trailingIcon = {
                                IconButton(onClick = { showConfirm = !showConfirm }) {
                                    Icon(if (showConfirm) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                                }
                            },
                            visualTransformation = if (showConfirm) VisualTransformation.None else PasswordVisualTransformation(),
                            shape = RoundedCornerShape(18.dp)
                        )
                    }
                }

                AnimatedVisibility(error != null) {
                    Surface(
                        modifier = Modifier.padding(top = 14.dp).fillMaxWidth(),
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            error.orEmpty(),
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = { onSubmit(password, confirm) },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(if (hasVault) Icons.Default.LockOpen else Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (hasVault) "باز کردن Vault" else "ساخت Vault", fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "داده‌ها فقط روی دستگاه و به‌صورت رمزگذاری‌شده ذخیره می‌شوند.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
fun VaultAppScreen(
    vault: VaultData,
    master: String,
    store: VaultStore,
    themeMode: String,
    autoLockSeconds: Int,
    onActivity: () -> Unit,
    onVaultChanged: (VaultData) -> Unit,
    onMasterChanged: (String) -> Unit,
    onThemeModeChanged: (String) -> Unit,
    onAutoLockChanged: (Int) -> Unit,
    onRestore: (VaultData) -> Unit,
    onLock: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var tab by remember { mutableStateOf(AppTab.HOME) }
    var editing by remember { mutableStateOf<VaultEntry?>(null) }
    var creating by remember { mutableStateOf(false) }
    var changeMaster by remember { mutableStateOf(false) }

    val backupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                store.writeBackup(uri)
                scope.launch { snackbar.showSnackbar("بکاپ رمزگذاری‌شده ذخیره شد.") }
            } catch (_: Exception) {
                scope.launch { snackbar.showSnackbar("ذخیره بکاپ ناموفق بود.") }
            }
        }
    }

    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val raw = store.readBackup(uri)
                val restored = store.restoreRaw(raw, master.toCharArray())
                onRestore(restored)
                scope.launch { snackbar.showSnackbar("بکاپ با موفقیت بازیابی شد.") }
            } catch (_: Exception) {
                scope.launch { snackbar.showSnackbar("بکاپ با رمز اصلی فعلی باز نشد یا معتبر نیست.") }
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbar) },
            topBar = {
                Surface(tonalElevation = 2.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(GradientA, GradientB))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, null, tint = Color.White, modifier = Modifier.size(23.dp))
                        }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("SecureVault", fontWeight = FontWeight.Black, fontSize = 19.sp)
                            Text(
                                when (tab) {
                                    AppTab.HOME -> "${vault.entries.size} حساب امن"
                                    AppTab.GENERATOR -> "Password Generator"
                                    AppTab.SECURITY -> "Security Center"
                                    AppTab.SETTINGS -> "تنظیمات و بکاپ"
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { onActivity(); onLock() }) {
                            Icon(Icons.Default.Lock, contentDescription = "قفل")
                        }
                    }
                }
            },
            bottomBar = {
                NavigationBar {
                    AppTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { onActivity(); tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        AppTab.HOME -> Icons.Default.Home
                                        AppTab.GENERATOR -> Icons.Default.Password
                                        AppTab.SECURITY -> Icons.Default.Security
                                        AppTab.SETTINGS -> Icons.Default.Settings
                                    },
                                    contentDescription = item.label
                                )
                            },
                            label = { Text(item.label, fontSize = 10.sp) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (tab == AppTab.HOME) {
                    FloatingActionButton(onClick = { onActivity(); creating = true }) {
                        Icon(Icons.Default.Add, contentDescription = "افزودن")
                    }
                }
            }
        ) { padding ->
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.fillMaxSize().padding(padding),
                transitionSpec = {
                    (fadeIn(tween(180)) + slideInHorizontally(tween(220)) { it / 12 }) togetherWith
                        (fadeOut(tween(120)) + slideOutHorizontally(tween(180)) { -it / 12 })
                },
                label = "tabs"
            ) { selected ->
                when (selected) {
                    AppTab.HOME -> HomeScreen(
                        entries = vault.entries,
                        onActivity = onActivity,
                        onEdit = { editing = it },
                        onDelete = { entry ->
                            val changed = vault.copy(entries = vault.entries.filterNot { it.id == entry.id }.toMutableList())
                            onVaultChanged(changed)
                        },
                        onCopy = { value ->
                            secureCopy(context, value)
                            scope.launch { snackbar.showSnackbar("کپی شد؛ Clipboard بعداً پاک می‌شود.") }
                        }
                    )

                    AppTab.GENERATOR -> GeneratorScreen(
                        onActivity = onActivity,
                        onCopy = { value ->
                            secureCopy(context, value)
                            scope.launch { snackbar.showSnackbar("رمز تولیدشده کپی شد.") }
                        }
                    )

                    AppTab.SECURITY -> SecurityScreen(vault.entries)

                    AppTab.SETTINGS -> SettingsScreen(
                        themeMode = themeMode,
                        autoLockSeconds = autoLockSeconds,
                        onThemeModeChanged = { onActivity(); onThemeModeChanged(it) },
                        onAutoLockChanged = { onActivity(); onAutoLockChanged(it) },
                        onBackup = {
                            onActivity()
                            backupLauncher.launch("SecureVault-backup.svault.json")
                        },
                        onRestore = {
                            onActivity()
                            restoreLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
                        },
                        onChangeMaster = { onActivity(); changeMaster = true },
                        onLock = onLock
                    )
                }
            }
        }
    }

    if (creating) {
        EntryDialog(
            initial = null,
            onDismiss = { creating = false },
            onSave = { entry ->
                val changed = vault.copy(entries = (vault.entries + entry).toMutableList())
                onVaultChanged(changed)
                creating = false
            }
        )
    }

    editing?.let { current ->
        EntryDialog(
            initial = current,
            onDismiss = { editing = null },
            onSave = { updated ->
                val changed = vault.copy(
                    entries = vault.entries.map { if (it.id == current.id) updated.copy(id = current.id, createdAt = current.createdAt) else it }.toMutableList()
                )
                onVaultChanged(changed)
                editing = null
            }
        )
    }

    if (changeMaster) {
        ChangeMasterDialog(
            onDismiss = { changeMaster = false },
            onChange = { current, next ->
                try {
                    store.load(current.toCharArray())
                    store.save(vault, next.toCharArray())
                    onMasterChanged(next)
                    changeMaster = false
                    scope.launch { snackbar.showSnackbar("رمز اصلی تغییر کرد.") }
                } catch (_: Exception) {
                    scope.launch { snackbar.showSnackbar("رمز اصلی فعلی اشتباه است.") }
                }
            }
        )
    }
}

@Composable
private fun HomeScreen(
    entries: List<VaultEntry>,
    onActivity: () -> Unit,
    onEdit: (VaultEntry) -> Unit,
    onDelete: (VaultEntry) -> Unit,
    onCopy: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<VaultEntry?>(null) }
    val filtered = remember(entries, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) entries.sortedByDescending { it.updatedAt }
        else entries.filter {
            it.title.lowercase().contains(q) ||
                it.username.lowercase().contains(q) ||
                it.website.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }.sortedByDescending { it.updatedAt }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it; onActivity() },
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            placeholder = { Text("جست‌وجوی حساب، سایت یا دسته‌بندی...") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                AnimatedVisibility(query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, null) }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )

        if (filtered.isEmpty()) {
            EmptyVault(hasQuery = query.isNotBlank())
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(11.dp)
            ) {
                items(filtered, key = { it.id }) { entry ->
                    EntryCard(
                        entry = entry,
                        onActivity = onActivity,
                        onEdit = { onEdit(entry) },
                        onDelete = { pendingDelete = entry },
                        onCopy = onCopy
                    )
                }
            }
        }
    }

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            icon = { Icon(Icons.Default.Delete, null) },
            title = { Text("حذف ${entry.title}؟") },
            text = { Text("این حساب از Vault حذف می‌شود و قابل بازگردانی نیست مگر اینکه بکاپ داشته باشی.") },
            confirmButton = {
                TextButton(onClick = { onDelete(entry); pendingDelete = null }) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("انصراف") } }
        )
    }
}

@Composable
private fun EmptyVault(hasQuery: Boolean) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                Icon(
                    if (hasQuery) Icons.Default.SearchOff else Icons.Default.Key,
                    null,
                    modifier = Modifier.padding(22.dp).size(42.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(if (hasQuery) "چیزی پیدا نشد" else "Vault هنوز خالیه", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                if (hasQuery) "عبارت جست‌وجو رو تغییر بده." else "با دکمه + اولین حساب رو اضافه کن.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
    }
}

@Composable
private fun EntryCard(
    entry: VaultEntry,
    onActivity: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCopy: (String) -> Unit
) {
    var reveal by remember(entry.id) { mutableStateOf(false) }
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(entry.title.trim().take(1).ifBlank { "?" }.uppercase(), fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(entry.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(
                        entry.username.ifBlank { entry.website.ifBlank { "بدون نام کاربری" } },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
                AssistChip(onClick = {}, label = { Text(entry.category, fontSize = 10.sp) })
            }

            Spacer(Modifier.height(14.dp))
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, top = 7.dp, bottom = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (reveal) entry.password else "••••••••••••",
                        modifier = Modifier.weight(1f),
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                    IconButton(onClick = { onActivity(); reveal = !reveal }) {
                        Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                    IconButton(onClick = { onActivity(); onCopy(entry.password) }, enabled = entry.password.isNotEmpty()) {
                        Icon(Icons.Default.ContentCopy, null)
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { onActivity(); onEdit() }) {
                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("ویرایش")
                }
                TextButton(onClick = { onActivity(); onDelete() }) {
                    Icon(Icons.Default.DeleteOutline, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("حذف")
                }
            }
        }
    }
}

@Composable
private fun EntryDialog(initial: VaultEntry?, onDismiss: () -> Unit, onSave: (VaultEntry) -> Unit) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var username by remember { mutableStateOf(initial?.username.orEmpty()) }
    var password by remember { mutableStateOf(initial?.password.orEmpty()) }
    var website by remember { mutableStateOf(initial?.website.orEmpty()) }
    var notes by remember { mutableStateOf(initial?.notes.orEmpty()) }
    var category by remember { mutableStateOf(initial?.category ?: "عمومی") }
    var showPassword by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "افزودن حساب" else "ویرایش حساب") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(title, { title = it }, label = { Text("نام حساب *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(username, { username = it }, label = { Text("نام کاربری / ایمیل") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    password,
                    { password = it },
                    label = { Text("رمز عبور") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        Row {
                            IconButton(onClick = { password = PasswordTools.generate() }) { Icon(Icons.Default.AutoAwesome, null) }
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                            }
                        }
                    }
                )
                if (password.isNotEmpty()) {
                    val score = PasswordTools.strength(password)
                    LinearProgressIndicator(
                        progress = { score / 5f },
                        modifier = Modifier.fillMaxWidth().clip(CircleShape)
                    )
                    Text("قدرت رمز: ${strengthLabel(score)}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                OutlinedTextField(website, { website = it }, label = { Text("وب‌سایت") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(category, { category = it }, label = { Text("دسته‌بندی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank()) {
                    error = "نام حساب رو وارد کن."
                } else {
                    onSave(
                        VaultEntry(
                            id = initial?.id ?: java.util.UUID.randomUUID().toString(),
                            title = title.trim(),
                            username = username.trim(),
                            password = password,
                            website = website.trim(),
                            notes = notes.trim(),
                            category = category.trim().ifBlank { "عمومی" },
                            createdAt = initial?.createdAt ?: System.currentTimeMillis(),
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
            }) {
                Icon(Icons.Default.Save, null)
                Spacer(Modifier.width(6.dp))
                Text("ذخیره")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun GeneratorScreen(onActivity: () -> Unit, onCopy: (String) -> Unit) {
    var length by remember { mutableFloatStateOf(20f) }
    var uppercase by remember { mutableStateOf(true) }
    var digits by remember { mutableStateOf(true) }
    var symbols by remember { mutableStateOf(true) }
    var generated by remember { mutableStateOf(PasswordTools.generate()) }
    var reveal by remember { mutableStateOf(true) }

    fun regenerate() {
        generated = PasswordTools.generate(length.toInt(), uppercase, digits, symbols)
        onActivity()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("تولید رمز قوی", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("رمزها روی خود دستگاه تولید می‌شن و جایی ارسال نمی‌شن.", color = MaterialTheme.colorScheme.onSurfaceVariant)

        Card(shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("طول رمز", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text(length.toInt().toString(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                }
                Slider(
                    value = length,
                    onValueChange = { length = it; regenerate() },
                    valueRange = 12f..64f,
                    steps = 51
                )
                ToggleRow("حروف بزرگ A-Z", uppercase) { uppercase = it; regenerate() }
                ToggleRow("عدد 0-9", digits) { digits = it; regenerate() }
                ToggleRow("نمادها", symbols) { symbols = it; regenerate() }
            }
        }

        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(18.dp)) {
                Text("رمز تولیدشده", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Spacer(Modifier.height(8.dp))
                Text(
                    if (reveal) generated else "••••••••••••••••••",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(10.dp))
                Row {
                    FilledTonalButton(onClick = { reveal = !reveal }) {
                        Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { onCopy(generated); onActivity() }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.ContentCopy, null)
                        Spacer(Modifier.width(7.dp))
                        Text("کپی")
                    }
                    Spacer(Modifier.width(8.dp))
                    FilledTonalButton(onClick = { regenerate() }) { Icon(Icons.Default.Refresh, null) }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun SecurityScreen(entries: List<VaultEntry>) {
    val weak = remember(entries) { PasswordTools.weakEntries(entries) }
    val reusedIds = remember(entries) { PasswordTools.reusedEntries(entries) }
    val score = remember(entries, weak, reusedIds) {
        if (entries.isEmpty()) 100 else ((1f - ((weak.size + reusedIds.size).coerceAtMost(entries.size).toFloat() / entries.size)) * 100).toInt()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp, 18.dp, 18.dp, 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                        Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.padding(15.dp).size(30.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("امتیاز امنیت Vault", fontWeight = FontWeight.Bold)
                        Text("$score از 100", fontSize = 28.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        item { StatCard("رمزهای ضعیف", weak.size, Icons.Default.WarningAmber, weak.isEmpty()) }
        item { StatCard("حساب‌های دارای رمز تکراری", reusedIds.size, Icons.Default.ContentCopy, reusedIds.isEmpty()) }

        if (weak.isNotEmpty() || reusedIds.isNotEmpty()) {
            item {
                Text("موارد نیازمند توجه", fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            }
            items(entries.filter { it in weak || it.id in reusedIds }, key = { "security-${it.id}" }) { entry ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.WarningAmber, null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(entry.title, fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    entry in weak && entry.id in reusedIds -> "رمز ضعیف و تکراری"
                                    entry in weak -> "رمز ضعیف"
                                    else -> "رمز تکراری"
                                },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        } else {
            item {
                Card(shape = RoundedCornerShape(22.dp)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("عالیه", fontWeight = FontWeight.Black)
                            Text("رمز ضعیف یا تکراری پیدا نشد.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        item {
            Text(
                "این بررسی فقط داخل Vault انجام می‌شه و سرویس نشت رمز آنلاین رو بررسی نمی‌کنه.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun StatCard(title: String, count: Int, icon: androidx.compose.ui.graphics.vector.ImageVector, good: Boolean) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (good) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(12.dp))
            Text(title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text(count.toString(), fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun SettingsScreen(
    themeMode: String,
    autoLockSeconds: Int,
    onThemeModeChanged: (String) -> Unit,
    onAutoLockChanged: (Int) -> Unit,
    onBackup: () -> Unit,
    onRestore: () -> Unit,
    onChangeMaster: () -> Unit,
    onLock: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("تنظیمات", fontWeight = FontWeight.Black, fontSize = 24.sp)

        SettingsCard("ظاهر", Icons.Default.Palette) {
            Text("تم برنامه", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = themeMode == "dark", onClick = { onThemeModeChanged("dark") }, label = { Text("تیره") }, leadingIcon = { Icon(Icons.Default.DarkMode, null, Modifier.size(17.dp)) })
                FilterChip(selected = themeMode == "light", onClick = { onThemeModeChanged("light") }, label = { Text("روشن") }, leadingIcon = { Icon(Icons.Default.LightMode, null, Modifier.size(17.dp)) })
                FilterChip(selected = themeMode == "system", onClick = { onThemeModeChanged("system") }, label = { Text("سیستم") })
            }
        }

        SettingsCard("قفل خودکار", Icons.Default.Timer) {
            Text("زمان فعلی: ${autoLockLabel(autoLockSeconds)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf(60, 180, 300).forEach { seconds ->
                    FilterChip(
                        selected = autoLockSeconds == seconds,
                        onClick = { onAutoLockChanged(seconds) },
                        label = { Text(autoLockLabel(seconds)) }
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("با رفتن برنامه به پس‌زمینه، Vault فوراً قفل می‌شود.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SettingsCard("بکاپ رمزگذاری‌شده", Icons.Default.Backup) {
            Text("فایل بکاپ بدون رمز اصلی قابل خواندن نیست.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row {
                Button(onClick = onBackup, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Backup, null)
                    Spacer(Modifier.width(6.dp))
                    Text("ساخت بکاپ")
                }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onRestore, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Restore, null)
                    Spacer(Modifier.width(6.dp))
                    Text("بازیابی")
                }
            }
        }

        SettingsCard("امنیت", Icons.Default.AdminPanelSettings) {
            ListItem(
                headlineContent = { Text("تغییر رمز اصلی") },
                supportingContent = { Text("Vault با رمز جدید دوباره رمزگذاری می‌شود.") },
                leadingContent = { Icon(Icons.Default.Key, null) },
                modifier = Modifier.clickable(onClick = onChangeMaster)
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text("قفل کردن الان") },
                supportingContent = { Text("داده‌های بازشده از حافظه برنامه پاک می‌شوند.") },
                leadingContent = { Icon(Icons.Default.Lock, null) },
                modifier = Modifier.clickable(onClick = onLock)
            )
        }

        SettingsCard("درباره", Icons.Default.Info) {
            Text("SecureVault 2.0", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Kotlin + Jetpack Compose • AES-256-GCM", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            Text("بدون مجوز اینترنت", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }

        Spacer(Modifier.height(90.dp))
    }
}

@Composable
private fun SettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Black, fontSize = 17.sp)
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun ChangeMasterDialog(onDismiss: () -> Unit, onChange: (String, String) -> Unit) {
    var current by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تغییر رمز اصلی") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SecureDialogField("رمز فعلی", current) { current = it }
                SecureDialogField("رمز جدید", next) { next = it }
                SecureDialogField("تکرار رمز جدید", confirm) { confirm = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
            }
        },
        confirmButton = {
            Button(onClick = {
                error = when {
                    next.length < 12 -> "رمز جدید باید حداقل ۱۲ کاراکتر باشد."
                    next != confirm -> "تکرار رمز جدید یکسان نیست."
                    next == current -> "رمز جدید باید با رمز فعلی فرق داشته باشد."
                    else -> null
                }
                if (error == null) onChange(current, next)
            }) { Text("تغییر رمز") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun SecureDialogField(label: String, value: String, onValue: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(label) },
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = { show = !show }) {
                Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
            }
        }
    )
}

private fun strengthLabel(score: Int) = when (score) {
    0, 1 -> "خیلی ضعیف"
    2 -> "ضعیف"
    3 -> "متوسط"
    4 -> "قوی"
    else -> "خیلی قوی"
}

private fun autoLockLabel(seconds: Int): String = when (seconds) {
    60 -> "۱ دقیقه"
    180 -> "۳ دقیقه"
    300 -> "۵ دقیقه"
    else -> "${seconds / 60} دقیقه"
}

private fun secureCopy(context: Context, value: String) {
    if (value.isEmpty()) return
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("SecureVault", value))
    Handler(Looper.getMainLooper()).postDelayed({
        val current = clipboard.primaryClip
        val text = current?.getItemAt(0)?.coerceToText(context)?.toString()
        if (text == value) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) clipboard.clearPrimaryClip()
            else clipboard.setPrimaryClip(ClipData.newPlainText("", ""))
        }
    }, 30_000L)
}
