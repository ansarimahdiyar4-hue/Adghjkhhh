package com.securevault.app

import android.content.Context

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("securevault_ui", Context.MODE_PRIVATE)

    var themeMode: String
        get() = prefs.getString("theme_mode", "dark") ?: "dark"
        set(value) = prefs.edit().putString("theme_mode", value).apply()

    var autoLockSeconds: Int
        get() = prefs.getInt("auto_lock_seconds", 180)
        set(value) = prefs.edit().putInt("auto_lock_seconds", value.coerceIn(30, 900)).apply()
}
