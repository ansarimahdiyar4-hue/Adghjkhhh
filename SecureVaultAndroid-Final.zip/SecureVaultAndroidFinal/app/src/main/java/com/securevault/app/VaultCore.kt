package com.securevault.app

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.google.gson.Gson
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class VaultEntry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val username: String = "",
    val password: String = "",
    val website: String = "",
    val notes: String = "",
    val category: String = "عمومی",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class VaultData(
    val version: Int = 1,
    val entries: MutableList<VaultEntry> = mutableListOf()
)

data class Envelope(
    val app: String = "SecureVault",
    val version: Int = 1,
    val kdf: String = "PBKDF2-HMAC-SHA256",
    val iterations: Int = VaultCrypto.ITERATIONS,
    val salt: String,
    val iv: String,
    val ciphertext: String
)

object VaultCrypto {
    const val ITERATIONS = 310_000
    private const val KEY_BITS = 256
    private const val AAD = "SecureVault-v1"
    private val random = SecureRandom()

    fun encrypt(json: String, password: CharArray): Envelope {
        require(password.size >= 12) { "Master password is too short" }
        val salt = ByteArray(16).also(random::nextBytes)
        val iv = ByteArray(12).also(random::nextBytes)
        val key = derive(password, salt, ITERATIONS)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        val encrypted = cipher.doFinal(json.toByteArray(Charsets.UTF_8))
        return Envelope(
            salt = Base64.encodeToString(salt, Base64.NO_WRAP),
            iv = Base64.encodeToString(iv, Base64.NO_WRAP),
            ciphertext = Base64.encodeToString(encrypted, Base64.NO_WRAP)
        )
    }

    fun decrypt(envelope: Envelope, password: CharArray): String {
        require(envelope.app == "SecureVault") { "Invalid vault" }
        require(envelope.version == 1) { "Unsupported vault version" }
        require(envelope.kdf == "PBKDF2-HMAC-SHA256") { "Unsupported KDF" }
        require(envelope.iterations in 100_000..1_000_000) { "Invalid KDF settings" }

        val salt = Base64.decode(envelope.salt, Base64.NO_WRAP)
        val iv = Base64.decode(envelope.iv, Base64.NO_WRAP)
        val encrypted = Base64.decode(envelope.ciphertext, Base64.NO_WRAP)
        require(salt.size == 16 && iv.size == 12) { "Invalid vault parameters" }

        val key = derive(password, salt, envelope.iterations)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        cipher.updateAAD(AAD.toByteArray(Charsets.UTF_8))
        return String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }

    private fun derive(password: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, iterations, KEY_BITS)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            SecretKeySpec(bytes, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}

class VaultStore(private val context: Context) {
    private val gson = Gson()
    private val file: File get() = File(context.filesDir, "vault.secure.json")

    fun exists(): Boolean = file.isFile

    @Synchronized
    fun save(data: VaultData, password: CharArray) {
        val envelope = VaultCrypto.encrypt(gson.toJson(data), password)
        atomicWrite(gson.toJson(envelope))
    }

    @Synchronized
    fun load(password: CharArray): VaultData {
        val raw = file.readText(Charsets.UTF_8)
        return decodeRaw(raw, password)
    }

    fun decodeRaw(raw: String, password: CharArray): VaultData {
        val envelope = gson.fromJson(raw, Envelope::class.java)
        val json = VaultCrypto.decrypt(envelope, password)
        return gson.fromJson(json, VaultData::class.java) ?: VaultData()
    }

    fun rawBackup(): String = file.readText(Charsets.UTF_8)

    @Synchronized
    fun restoreRaw(raw: String, password: CharArray): VaultData {
        val decoded = decodeRaw(raw, password)
        atomicWrite(raw)
        return decoded
    }

    fun writeBackup(uri: Uri) {
        val raw = rawBackup()
        context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
            out.write(raw.toByteArray(Charsets.UTF_8))
            out.flush()
        } ?: error("Unable to open backup destination")
    }

    fun readBackup(uri: Uri): String {
        return context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Unable to read backup")
    }

    private fun atomicWrite(text: String) {
        val tmp = File(context.filesDir, "vault.secure.tmp")
        FileOutputStream(tmp).use { output ->
            output.write(text.toByteArray(Charsets.UTF_8))
            output.fd.sync()
        }
        try {
            Files.move(
                tmp.toPath(),
                file.toPath(),
                StandardCopyOption.REPLACE_EXISTING,
                StandardCopyOption.ATOMIC_MOVE
            )
        } catch (_: Exception) {
            Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }
}

object PasswordTools {
    private val random = SecureRandom()
    private const val LOWER = "abcdefghijkmnopqrstuvwxyz"
    private const val UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    private const val DIGITS = "23456789"
    private const val SYMBOLS = "!@#%&*+-_=.?"

    fun generate(
        length: Int = 20,
        uppercase: Boolean = true,
        digits: Boolean = true,
        symbols: Boolean = true
    ): String {
        val finalLength = length.coerceIn(12, 64)
        val groups = buildList {
            add(LOWER)
            if (uppercase) add(UPPER)
            if (digits) add(DIGITS)
            if (symbols) add(SYMBOLS)
        }
        val all = groups.joinToString("")
        val chars = mutableListOf<Char>()
        groups.forEach { group -> chars += group[random.nextInt(group.length)] }
        while (chars.size < finalLength) chars += all[random.nextInt(all.length)]
        for (i in chars.lastIndex downTo 1) {
            val j = random.nextInt(i + 1)
            val t = chars[i]
            chars[i] = chars[j]
            chars[j] = t
        }
        return chars.joinToString("")
    }

    fun strength(password: String): Int {
        if (password.isEmpty()) return 0
        var score = 0
        if (password.length >= 12) score++
        if (password.length >= 16) score++
        if (password.any(Char::isLowerCase) && password.any(Char::isUpperCase)) score++
        if (password.any(Char::isDigit)) score++
        if (password.any { !it.isLetterOrDigit() }) score++
        return score.coerceIn(0, 5)
    }

    fun weakEntries(entries: List<VaultEntry>): List<VaultEntry> =
        entries.filter { it.password.isBlank() || strength(it.password) <= 2 }

    fun reusedEntries(entries: List<VaultEntry>): Set<String> =
        entries.filter { it.password.isNotBlank() }
            .groupBy { it.password }
            .filterValues { it.size > 1 }
            .values.flatten()
            .map { it.id }
            .toSet()
}
