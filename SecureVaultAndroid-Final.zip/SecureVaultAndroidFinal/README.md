# SecureVault Android

Native Android password vault rewritten in Kotlin + Jetpack Compose.

## Features
- AES-256-GCM encrypted local vault
- PBKDF2-HMAC-SHA256 master-key derivation
- Master password creation / unlock / change
- Add, edit, search and delete accounts
- Strong password generator
- Weak/reused-password Security Center
- Encrypted backup / restore using Android document picker
- Automatic lock after inactivity and immediately when app goes to background
- Clipboard auto-clear after 30 seconds without deleting newer clipboard content
- Dark / Light / System themes
- Material 3 UI, animated lock screen and animated tab transitions
- Adaptive launcher icon + splash screen
- Screenshots blocked while the app is open
- No INTERNET permission

## Open in Android Studio
Open the `SecureVaultAndroidFinal` folder as a Gradle project. Android Studio can sync it with Gradle 8.9.

The project intentionally does not contain a third-party downloaded `gradle-wrapper.jar`; Android Studio can use its configured Gradle installation or regenerate the wrapper from a trusted Gradle installation.

## Build APK
Android Studio: `Build` > `Build Bundle(s) / APK(s)` > `Build APK(s)`.

Minimum Android: 8.0 (API 26)
Target SDK: 35
